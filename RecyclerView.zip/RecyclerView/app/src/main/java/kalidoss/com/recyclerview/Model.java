package kalidoss.com.recyclerview;

/**
 * Created by Kalidoss on 17/02/16.
 */
public class Model {

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String name;
}
