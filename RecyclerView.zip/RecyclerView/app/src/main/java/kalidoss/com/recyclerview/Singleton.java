package kalidoss.com.recyclerview;

import java.util.ArrayList;

/**
 * Created by Kalidoss on 28/01/16.
 */
public class Singleton {

    private static volatile Singleton instance = null;

    public static Singleton getInstance() {
        if (instance == null) {
            synchronized (Singleton.class) {
                // Double check
                if (instance == null) {
                    instance = new Singleton();
                }
            }
        }
        return instance;
    }

    public ArrayList<Model> modelList = new ArrayList<Model>();
}
