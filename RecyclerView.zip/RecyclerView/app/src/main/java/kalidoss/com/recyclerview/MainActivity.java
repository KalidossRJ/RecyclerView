package kalidoss.com.recyclerview;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

/**
 * Created by Kalidoss on 28/01/16.
 */

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    RecyclerViewAdapter recyclerViewAdapter;
    Model model;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        addValues();
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        recyclerViewAdapter = new RecyclerViewAdapter(context);

        final LinearLayoutManager layoutManager = new LinearLayoutManager(context);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerView.isAnimating();

        recyclerView.addItemDecoration(new SimpleDividerItemDecoration(this));

        recyclerViewAdapter.setOnItemClickListener(new RecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View itemView, int position) {

                String name = Singleton.getInstance().modelList.get(position).getName();
                Toast.makeText(context, name + " was clicked!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void addValues() {
        model = new Model();
        model.setName("Kalidoss");
        Singleton.getInstance().modelList.add(model);

        model = new Model();
        model.setName("RJ");
        Singleton.getInstance().modelList.add(model);

        model = new Model();
        model.setName("Tamil");
        Singleton.getInstance().modelList.add(model);

        model = new Model();
        model.setName("Kd");
        Singleton.getInstance().modelList.add(model);

        model = new Model();
        model.setName("Hari");
        Singleton.getInstance().modelList.add(model);

        model = new Model();
        model.setName("Sampath");
        Singleton.getInstance().modelList.add(model);

        model = new Model();
        model.setName("Mani");
        Singleton.getInstance().modelList.add(model);

        model = new Model();
        model.setName("Sheik");
        Singleton.getInstance().modelList.add(model);

        model = new Model();
        model.setName("Niyas");
        Singleton.getInstance().modelList.add(model);
    }
}
